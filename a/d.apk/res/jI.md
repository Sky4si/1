# alpha更新日志

- 如果需要使用 heapprofd（Android Heap Profiler），请关闭zygisk并重启。
- `magisk`和`su`等二进制文件不再硬编码于`/system/bin/`目录下，而是从`PATH`环境变量中选择第一个可用位置。

## Magisk (50af14f2-alpha)
- [App] 还原boot镜像后删除备份文件
- [App] 不主动请求权限
- [General] 保留ROOTOVL临时文件
- [App] 通过appcenter检查和下载更新
- [App] 添加遥测 https://t.me/s/magiskalpha/473
- [General] 移除addon.d支持
- [MagiskSU] 支持移除权能
- [General] 支持用户限制Root权能
- [App] 为DoH禁用SNI
- [Zygisk] 修改 libzygisk.so 名字为 heapprofd_client.so
- [App] 适配 Android 16

# 上游更新日志

## Magisk (1e3edb88) (28103)

- [General] Massive internal refactoring and code migration
- [App] Fix patching Samsung's AP tar firmware files
- [MagiskInit] Redesign sepolicy patching and injection logic

## Diffs to v28.1

- [General] Massive internal refactoring and code migration
- [App] Support downloading module zip files with XZ compression
- [MagiskMount] Support systemlessly deleting files with modules using blank file nodes
- [MagiskInit] Redesign sepolicy patching and injection logic
